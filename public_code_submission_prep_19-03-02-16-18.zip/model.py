import numpy as np
import pickle
from sklearn.base import BaseEstimator
from sklearn.naive_bayes import GaussianNB
from sklearn import svm
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import GridSearchCV
from os.path import isfile
from sklearn import preprocessing
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn.feature_selection import VarianceThreshold
from sklearn.datasets import load_boston
from sklearn.feature_selection import SelectFromModel
from sklearn.linear_model import LassoCV
from sklearn.preprocessing import StandardScaler

def requires_grad(p):
    return p.requires_grad

def transforme(X):
    """
 Cette fonction transforme(X) va prendre le modèle X contenant les features et va faire  des modifications sur ces dernières.
    """

    """
Le standardscaler va être une étape à faire juste avant le variancetreshold afin que les features soient à la même échelle et ainsi améliorer le résultat de variancetreshold et du PCA.
en effet, sans le standardscaler, on a un score de 0.38 contre un score de 0.40 avec le standardscaler
    """
    #scaler=StandardScaler()
    #X=scaler.fit_transform(X)

    """
Vu que les données sont déjà préprocéssées, on ne spécifie pas de paramètre, nous allons le laisser à 0 et retirer toutes les features dont la variance est égale à 0. Ce qui est inutile parce que les données ont déjà vu leur features dont les variances sont égales à 0 retirées. Cependant, cette méthode va nous servir pour les raw data, nous spécifierons donc une variance prédéfinie, par exempe 0.05
    """
    #selector = VarianceThreshold()
    #X=scaler.fit_transform(X)

    """
Algorithme du principal component analysis (PCA) qui va s'occuper de transformer les features en de nouvelles features en spécifiant le nombre de features que l'on souhaite, ici on a 1024, soit le même nombre que les features actuelles pour les données préprocéssées.
    """
    #pca = PCA(n_components = 1024)
    #X=pca.fit_transform(X)

    """
Cette fonction retourne le nouveau modèle X correspondant et nous utilisé dans la fonction fit et predict pour que la prédiction prenne en compte le nouveau modèle modifié.
Nous avons décidé de laisser l'intégralité de toutes ces méthodes de la fonction en commentaire car celles-ci font baisser drastiquement le score, ce qui est normal car elles sont déjà préprocéssées. Nous arrivons à un résultat de 0.40 si on utilisait cette fonction transforme. Les résultats ne sont donc pas très bien pour ce projet, mais nous servira beaucoup pour la partie non préprocéssé à savoir le raw data.
    """
    return X


class baselineModel(BaseEstimator):
    def __init__(self, max_depth=5):
        """
        Utilisation de gridsearch pour trouver les meilleurs hyperparametres 
        """
        super(baselineModel, self).__init__()
        """
        
        #Definition d'une liste d'hyperparametres et valeurs à tester
        
        params = {'C': [6,7,8,9,10], 'kernel': ['linear','rbf'], 'degree':[4,5,6]}
        clf = svm.SVC()
        
        #test des parametres
        
        self.classifier = GridSearchCV(clf, param_grid=params, n_jobs=-1)
        """
        self.classifier = svm.SVC(C=8, kernel='linear', degree=4)
        self.num_train_samples=0
        self.num_feat=1
        self.num_labels=1
        self.is_trained=False

    def fit(self, X, y):
        X=transforme(X)
        self.num_train_samples = X.shape[0]
        if X.ndim>1: self.num_feat = X.shape[1]
        print("FIT: dim(X)= [{:d}, {:d}]".format(self.num_train_samples, self.num_feat))
        num_train_samples = y.shape[0]
        if y.ndim>1: self.num_labels = y.shape[1]
        print("FIT: dim(y)= [{:d}, {:d}]".format(num_train_samples, self.num_labels))
        if (self.num_train_samples != num_train_samples):
            print("ARRGH: number of samples in X and y do not match!")
        self.is_trained=True
        self.classifier.fit(X, y)
        """
        Affichage des meilleurs parametres trouvés
        """
        # print("Best Hyper Parameters:\n", self.classifier.best_params_)

    def predict(self, X):
        X=transforme(X)
        num_test_samples = X.shape[0]
        if X.ndim>1:
            num_feat = X.shape[1]
        print("PREDICT: dim(X)= [{:d}, {:d}]".format(num_test_samples, num_feat))
        if (self.num_feat != num_feat):
            print("ARRGH: number of features in X does not match training data!")
        print("PREDICT: dim(y)= [{:d}, {:d}]".format(num_test_samples, self.num_labels))
        y = np.zeros([num_test_samples, self.num_labels])
        return self.classifier.predict(X)

    def save(self, path="./"):
        pickle.dump(self, open(path + '_model.pickle', "wb"))

    def load(self, path="./"):
        modelfile = path + '_model.pickle'
        if isfile(modelfile):
            with open(modelfile, 'rb') as f:
                self = pickle.load(f)
            print("Model reloaded from: " + modelfile)
        return self
